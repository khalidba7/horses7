// تخزين بيانات المستخدم
document.addEventListener("DOMContentLoaded", () => {
    let username = localStorage.getItem("username");
    if (!username) {
        username = prompt("أدخل اسمك للتسجيل:");
        localStorage.setItem("username", username);
    }
    console.log("مرحباً", username);
});