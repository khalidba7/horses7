// ملف إعداد Firebase
// قم بإضافة بيانات مشروعك من Firebase هنا
const firebaseConfig = {
    apiKey: "",
    authDomain: "",
    projectId: "",
    storageBucket: "",
    messagingSenderId: "",
    appId: ""
};
firebase.initializeApp(firebaseConfig);
